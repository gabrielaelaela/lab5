package organization;

import exceptions.WrongInputException;
import interfaces.IdObject;

import java.time.LocalDate;

public class Organization implements IdObject, Comparable<IdObject> {
    private int id; //Значение поля должно быть больше 0, Значение этого поля должно быть уникальным, Значение этого поля должно генерироваться автоматически
    private String name; //Поле не может быть null, Строка не может быть пустой
    private Coordinates coordinates; //Поле не может быть null
    private java.time.LocalDate creationDate; //Поле не может быть null, Значение этого поля должно генерироваться автоматически
    private long annualTurnover; //Значение поля должно быть больше 0
    private OrganizationType type; //Поле может быть null
    private Address postalAddress; //Поле не может быть null

    public Organization(String name, Coordinates coordinates, long annualTurnover, OrganizationType type, Address postalAddress) {
        id = (int) (Math.random()*2000000000);
        if (name == null || name.isEmpty()) throw new WrongInputException("Wrong name of organization");
        this.name = name;
        if (coordinates == null) throw new WrongInputException("Null coordinates");
        this.coordinates = coordinates;
        creationDate = LocalDate.now();
        if (annualTurnover <= 0) throw new WrongInputException("Annual turnover should be bigger than 0");
        this.annualTurnover = annualTurnover;
        if (type == null) throw new WrongInputException("Organization type may not be null");
        this.type = type;
        if (postalAddress == null) throw new WrongInputException("Postal address may not be null");
        this.postalAddress = postalAddress;
    }

    public int getId() {
        return this.id;
    }

    public enum OrganizationType {
        PUBLIC,
        PRIVATE_LIMITED_COMPANY,
        OPEN_JOINT_STOCK_COMPANY;
    }

    public void setId(int newId) {
        this.id = newId;
    }

    public String toString() {
        return this.id + ": " + this.name + ", postal address: " + this.postalAddress;
    }

    @Override
    public int compareTo(IdObject o) {
        if (this == o) {
            return 0;
        }
        if (o == null) {
            return 1;
        }
        return this.getId()-o.getId();
    }

    public long getAnnualTurnover() {
        return annualTurnover;
    }
}


