package interfaces;

public interface IdObject {
    int getId();
    void setId(int id);
}
