package exceptions;

public class WrongCommandException extends RuntimeException{
    public WrongCommandException(String s) {
        super(s);
    }
}
