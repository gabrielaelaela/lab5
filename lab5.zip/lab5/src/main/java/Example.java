import interfaces.IdObject;

public class Example implements IdObject, Comparable<IdObject> {
    private int id;
    private String name;

    public Example(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int compareTo(IdObject o) {
        if (this == o) {
            return 0;
        }
        if (o == null) {
            return 1;
        }
        return this.getId()-o.getId();
    }

    public String toString() {
        return this.id + ": " + name;
    }
}
