package commands;

import iowork.FileScan;
import iowork.Scannable;
import history.HistoryOfCommands;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

import java.util.Arrays;

public class ExecuteScriptCommand implements UserCommand{

    private String fileName;
    private UpgradedPriorityQueue<Organization> upgradedPriorityQueue;

    public ExecuteScriptCommand(UpgradedPriorityQueue<Organization> upgradedPriorityQueue, String fileName) {
        this.fileName = fileName;
        this.upgradedPriorityQueue = upgradedPriorityQueue;
    }

    @Override
    public void execute() {
        try {
            Scannable fileScan = new FileScan(fileName);
            CommandReader commandReader = new CommandReader(upgradedPriorityQueue);
            for (UserCommand userCommand : commandReader.commandsFromFile(fileScan)) {
                HistoryOfCommands.getInstance().addCommandToHistory(userCommand);
                userCommand.execute();
            }
        } catch (Exception e) {
            e.toString();
        }
    }

    @Override
    public String toString() {
        return "execute script";
    }
    public static String name(){
        return "execute_script";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(1,0,true,false, Arrays.asList("file name"), null);
    }
}
