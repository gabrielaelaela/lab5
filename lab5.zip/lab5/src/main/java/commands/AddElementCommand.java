package commands;

import history.HistoryOfCommands;
import organization.Organization;
import organization.OrganizationFactory;
import upgradedcollections.UpgradedPriorityQueue;

import java.util.Arrays;

public class AddElementCommand implements UserCommand{

    private UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue;
    private Organization organization;

    public AddElementCommand(UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue, Organization organization) {
        this.organizationUpgradedPriorityQueue = organizationUpgradedPriorityQueue;
        this.organization = organization;
    }

    @Override
    public void execute() {
        this.organizationUpgradedPriorityQueue.add(organization);
    }

    @Override
    public String toString() {
        return "add";
    }

    public static String name() {
        return "add";
    }
    public static CommandInfo getInfo() throws Exception {
        return new CommandInfo(0,1,true,false, null, Arrays.asList(OrganizationFactory.class));
    }
}
