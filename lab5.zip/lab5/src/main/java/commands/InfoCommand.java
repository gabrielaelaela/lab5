package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;

public class InfoCommand implements UserCommand {

    private UpgradedPriorityQueue<?> queue;
    private Printable printable;

    public InfoCommand(UpgradedPriorityQueue<?> queue, Printable printable) {
        this.queue = queue;
        this.printable = printable;
    }

    @Override
    public void execute() {
        try {
            printable.println("Type: " + queue.getClass());
            printable.println("Creation date: " + queue.getCreationDate());
            printable.println("Number of the elements: " + queue.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "info";
    }
    public static String name() {
        return "info";
    }

    public static CommandInfo getInfo() {
        return new CommandInfo(0,0,true,true, null, null);
    }
}
