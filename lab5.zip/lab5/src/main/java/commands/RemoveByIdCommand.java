package commands;

import history.HistoryOfCommands;
import interfaces.IdObject;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;
import java.util.Arrays;

public class RemoveByIdCommand implements UserCommand {
    private UpgradedPriorityQueue<IdObject> priorityQueue;
    private int id;

    public RemoveByIdCommand(UpgradedPriorityQueue<IdObject> priorityQueue, int id) {
        this.priorityQueue = priorityQueue;
        this.id = id;
    }

    @Override
    public void execute() throws IOException {
        IdObject idObject = this.priorityQueue.getElementById(id);
        this.priorityQueue.remove(idObject);
    }

    @Override
    public String toString() {
        return "remove by id";
    }
    public static String name() {
        return "remove_by_id";
    }
    public static CommandInfo getInfo() {
        return new CommandInfo(1,0,true,false, Arrays.asList("id to remove"), null);
    }
}
