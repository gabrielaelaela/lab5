package commands;

import history.HistoryOfCommands;

public class ExitCommand implements UserCommand{
    @Override
    public void execute() {
        System.exit(0);
    }

    @Override
    public String toString() {
        return "exit";
    }
    public static String name() {
        return "exit";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(0,0,false,false, null, null);
    }
}
