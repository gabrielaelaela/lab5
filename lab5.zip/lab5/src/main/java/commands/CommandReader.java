package commands;

import exceptions.WrongCommandException;
import iowork.ConsolePrint;
import iowork.ConsoleScan;
import iowork.Printable;
import iowork.Scannable;
import constructors.Constructor;
import org.reflections.Reflections;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandReader {

    private UpgradedPriorityQueue<Organization> organizationQueue;
    private ArrayList<UserCommand> listOfCommands;

    public CommandReader(UpgradedPriorityQueue<Organization> organizationQueue) {
        this.organizationQueue = organizationQueue;
    }

    private Class<? extends UserCommand> getCommand(String commandName) throws Exception {
        Reflections reflections = new Reflections("commands");
        for (Class<? extends UserCommand> command : reflections.getSubTypesOf(UserCommand.class)) {
            if (command.getMethod("name").invoke(null).equals(commandName.trim())){
                return command;
            }
        }
        throw new WrongCommandException("Incorrect command");
    }
    private CommandInfo getCommandInfo(Class<? extends UserCommand> command) throws Exception {
        return (CommandInfo) command.getMethod("getInfo").invoke(null);
    }

    private List<String> getWordList(String line) {
        return Arrays.asList(line.split("[ \r]"));
    }

    private List<String> askSimpleArgs(CommandInfo commandInfo, Printable printable, Scannable scannable) throws Exception {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < commandInfo.getSimpleArgs(); ++i){
            printable.print("Please enter " + commandInfo.getListOfDescription().get(i) + ": ");
            list.add(scannable.scanLine());
        }
        return list;
    }

    private List<Object> askComplexArgs(Class<? extends UserCommand> command, CommandInfo commandInfo, Printable printable, Scannable scannable) throws Exception {
        List<Object> list = new ArrayList<>();
        for (int i = 0; i < commandInfo.getComplexArgs(); ++i){
            Constructor constructor = (Constructor) commandInfo.getComplexConstructors().get(i).getConstructors()[0].newInstance(printable, scannable);
            list.add(constructor.askConstruct());
        }
        return list;
    }

    private UserCommand createCommand(Class<? extends UserCommand> command, CommandInfo commandInfo, Printable printable, List<String> simpleArgs, List<Object> complexArgs) throws Exception {
        List<Object> finalArgs = new ArrayList<>();
        if (commandInfo.getIsQueue()){
            finalArgs.add(organizationQueue);
        }
        if (commandInfo.getIsPrintable()){
            finalArgs.add(printable);
        }
        finalArgs.addAll(simpleArgs);
        finalArgs.addAll(complexArgs);
        return (UserCommand) command.getConstructors()[0].newInstance(finalArgs.toArray());
    }

    private List<String> scanSimpleArgs(CommandInfo commandInfo, List<String> words) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < commandInfo.getSimpleArgs(); ++i){
            list.add(words.get(1 + i));
        }
        return list;
    }

    private List<Object> scanComplexArgs(Class<? extends UserCommand> command, CommandInfo commandInfo, Printable printable, Scannable scannable) throws Exception {
        List<Object> list = new ArrayList<>();
        for (int i = 0; i < commandInfo.getComplexArgs(); ++i){
            Constructor constructor = (Constructor) commandInfo.getComplexConstructors().get(i).getConstructors()[0].newInstance(printable, scannable);
            list.add(constructor.scanConstruct());
        }
        return list;
    }

    public UserCommand commandFromConsole() throws Exception {
        Printable printable = new ConsolePrint();
        Scannable scannable = new ConsoleScan(printable);
        printable.print("Enter command name: ");

        String nextCommand = scannable.scanLine();

        Class<? extends UserCommand> command = getCommand(nextCommand);
        CommandInfo commandInfo = getCommandInfo(command);

        List<String> simpleArgs = askSimpleArgs(commandInfo, printable, scannable);
        List<Object> complexArgs = askComplexArgs(command, commandInfo, printable, scannable);

        UserCommand userCommand = createCommand(command, commandInfo, printable, simpleArgs, complexArgs);
        return userCommand;
    }

    public List<UserCommand> commandsFromFile(Scannable scannable) throws Exception {
        List<UserCommand> userCommands = new ArrayList<>();
        while (scannable.hasNextLine()){
            String line = scannable.scanLine();
            if (line == null)
                break;
            if (line.equals(""))
                continue;
            List<String> words = getWordList(line);

            Class<? extends UserCommand> command;

            try {
                command = getCommand(words.get(0));
            } catch (WrongCommandException e) {
                System.out.println(e.getMessage());
                break;
            }
            CommandInfo commandInfo = getCommandInfo(command);

            List<String> simpleArgs = scanSimpleArgs(commandInfo, words);
            List<Object> complexArgs = scanComplexArgs(command, commandInfo, null, scannable);
            UserCommand userCommand = createCommand(command, commandInfo, new ConsolePrint(), simpleArgs, complexArgs);
            userCommands.add(userCommand);
        }
        return userCommands;
    }
}
