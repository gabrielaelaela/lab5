package commands;

import com.google.gson.GsonBuilder;
import history.HistoryOfCommands;
import iowork.FilePrint;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

import com.google.gson.Gson;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;

public class SaveCommand implements UserCommand {

    private UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue;
    private String fileName;

    public SaveCommand(UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue, String fileName) {
        this.organizationUpgradedPriorityQueue = organizationUpgradedPriorityQueue;
        this.fileName = fileName;
    }

    @Override
    public void execute() throws FileNotFoundException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            new FilePrint(fileName).println(gson.toJson(this.organizationUpgradedPriorityQueue));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "save";
    }

    public static String name() {
        return "save";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(1,0,true,false, Arrays.asList("filename"), null);
    }
}
