package commands;

import history.HistoryOfCommands;
import interfaces.IdObject;
import organization.Organization;
import organization.OrganizationFactory;
import upgradedcollections.UpgradedPriorityQueue;

import java.util.Arrays;

public class UpdateIdCommand implements UserCommand{

    private UpgradedPriorityQueue<IdObject> priorityQueue;
    private Organization organization;

    public UpdateIdCommand(UpgradedPriorityQueue<IdObject> priorityQueue, Organization organization) {
        this.priorityQueue = priorityQueue;
        this.organization = organization;
    }

    @Override
    public void execute() {
        int id = organization.getId();
        this.priorityQueue.remove(this.priorityQueue.getElementById(id));
        this.priorityQueue.add(organization);
    }

    @Override
    public String toString() {
        return "update id";
    }
    public static String name() {
        return "update_id";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(0,1,true,false, null, Arrays.asList(OrganizationFactory.class));
    }
}
