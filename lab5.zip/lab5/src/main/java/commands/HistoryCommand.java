package commands;

import iowork.Printable;
import history.HistoryOfCommands;

import java.io.IOException;

public class HistoryCommand implements UserCommand{

    private Printable printable;

    public HistoryCommand(Printable printable) {
        this.printable = printable;
    }

    @Override
    public void execute() {
        int length = HistoryOfCommands.getInstance().getLength();
        for (int i = 0; i < length; i++) {
            try {
                printable.println(HistoryOfCommands.getInstance().get(i).toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public String toString() {
        return "history";
    }
    public static String name() {
        return "history";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(0,0,false,true, null, null);
    }
}
