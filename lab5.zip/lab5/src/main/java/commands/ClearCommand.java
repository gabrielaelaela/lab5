package commands;

import history.HistoryOfCommands;
import interfaces.IdObject;
import upgradedcollections.UpgradedPriorityQueue;

public class ClearCommand implements UserCommand{

    private UpgradedPriorityQueue<IdObject> priorityQueue;

    public ClearCommand(UpgradedPriorityQueue<IdObject> priorityQueue) {
        this.priorityQueue = priorityQueue;
    }

    @Override
    public void execute() {
        this.priorityQueue.clear();
    }

    @Override
    public String toString() {
        return "clear";
    }
    public static String name() {
        return "clear";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(0,0,true,false, null, null);
    }
}
