package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import organization.Organization;
import organization.OrganizationFactory;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;
import java.util.Arrays;

public class AddIfMinCommand implements UserCommand{

    private Organization organization;
    private UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue;
    private Printable printable;

    public AddIfMinCommand(UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue, Printable printable, Organization organization) {
        this.organization = organization;
        this.organizationUpgradedPriorityQueue = organizationUpgradedPriorityQueue;
        this.printable = printable;
    }

    @Override
    public void execute() throws IOException {
        if (organization.getId() < organizationUpgradedPriorityQueue.peek().getId())  {
            this.organizationUpgradedPriorityQueue.add(organization);
            printable.println("The organization was added");
        } else {
            printable.print("The organization was not added");
        }
    }

    @Override
    public String toString() {
        return "add if min";
    }

    public static String name() {
        return "add_if_min";
    }

    public static CommandInfo getInfo() {
        return new CommandInfo(0, 1, true, true, null, Arrays.asList(OrganizationFactory.class));
    }
}
