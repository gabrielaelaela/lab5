package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;
import java.util.Arrays;

public class CountGreaterThanAnnualTurnoverCommand implements UserCommand{

    private long annualTurnover;
    private UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue;
    private Printable printable;

    public CountGreaterThanAnnualTurnoverCommand(UpgradedPriorityQueue<Organization> organizationUpgradedPriorityQueue, Printable printable, String annualTurnover) {
        this.annualTurnover = Long.parseLong(annualTurnover);
        this.organizationUpgradedPriorityQueue = organizationUpgradedPriorityQueue;
    }

    @Override
    public void execute() throws IOException {
        int number = (int) organizationUpgradedPriorityQueue.stream().filter(elem -> elem.getAnnualTurnover() > this.annualTurnover).count();
        printable.println(String.valueOf(number));
    }

    @Override
    public String toString() {return "count greater than annual turnover";}

    public static String name() {return "count_greater_than_annual_turnover";}

    public static CommandInfo getInfo() {
        return new CommandInfo(1, 0, true, true, Arrays.asList("annual turnover"), null);
    }
}
