package commands;

import constructors.Constructor;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public class CommandInfo {

    private int simpleArgs;
    private int complexArgs;
    private boolean isQueue;
    private boolean isPrintable;
    private List<String> listOfDescription;
    private List<Class<? extends Constructor>> complexConstructors;

    public CommandInfo(int simpleArgs, int complexArgs, boolean isQueue, boolean isPrintable, List<String> description, List<Class<? extends Constructor>> complexConstructors) {
        this.simpleArgs = simpleArgs;
        this.complexArgs = complexArgs;
        this.isQueue = isQueue;
        this.isPrintable = isPrintable;
        this.listOfDescription = description;
        this.complexConstructors = complexConstructors;
    }

    public int getSimpleArgs(){
        return simpleArgs;
    }

    public int getComplexArgs(){
        return complexArgs;
    }

    public boolean getIsQueue(){
        return isQueue;
    }

    public boolean getIsPrintable(){
        return isPrintable;
    }

    public List<String> getListOfDescription() {
        return listOfDescription;
    }

    public List<Class<? extends Constructor>> getComplexConstructors() {
        return complexConstructors;
    }
}
