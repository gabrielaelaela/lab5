package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import upgradedcollections.UpgradedPriorityQueue;
import java.io.IOException;

public class PrintAscendingCommand implements UserCommand{

    private Printable printable;
    private UpgradedPriorityQueue<?> queue;

    public PrintAscendingCommand(UpgradedPriorityQueue<?> queue, Printable printable) {
        this.printable = printable;
        this.queue = queue;
    }

    @Override
    public void execute() throws IOException {
        queue.forEach(elem -> {
            try {
                printable.println(elem.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public String toString() {
        return "print ascending";
    }
    public static String name() {
        return "print_ascending";
    }

    public static CommandInfo getInfo() {
        return new CommandInfo(0, 0, true, true, null, null);
    }
}
