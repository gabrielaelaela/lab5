package commands;

import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;

public interface UserCommand {
    void execute() throws IOException;
}
