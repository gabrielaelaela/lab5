package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PrintDescendingCommand implements UserCommand{

    private Printable printable;
    private UpgradedPriorityQueue<?> queue;

    public PrintDescendingCommand(UpgradedPriorityQueue<?> queue, Printable printable) {
        this.printable = printable;
        this.queue = queue;
    }

    @Override
    public void execute() throws IOException {
        List<?> queueInList = new ArrayList<Object>(queue);
        for(int i = queueInList.size()-1; i > -1; i--) {
            printable.print(queueInList.get(i).toString());
        }
    }

    @Override
    public String toString() {
        return "print descending";
    }

    public static String name() {
        return "print_descending";
    }

    public static CommandInfo getInfo() {
        return new CommandInfo(0, 0, true, true, null, null);
    }
}
