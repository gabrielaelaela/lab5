package commands;

import iowork.Printable;
import history.HistoryOfCommands;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.IOException;

public class ShowCommand implements UserCommand{

    private UpgradedPriorityQueue<?> queue;
    private Printable printable;

    public ShowCommand(UpgradedPriorityQueue<?> queue, Printable printable) {
        this.queue = queue;
        this.printable = printable;
    }

    @Override
    public void execute() {
        queue.forEach(elem -> {
            try {
                printable.println(elem.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        if (queue.isEmpty()) System.out.println("The collection is empty");
    }

    @Override
    public String toString() {
        return "show";
    }
    public static String name() {
        return "show";
    }
    public static CommandInfo getInfo(){
        return new CommandInfo(0,0,true,true, null, null);
    }
}
