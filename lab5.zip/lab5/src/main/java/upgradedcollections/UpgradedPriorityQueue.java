package upgradedcollections;

import exceptions.WrongClassException;
import interfaces.IdObject;
import organization.Organization;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.PriorityQueue;

public class UpgradedPriorityQueue<T> extends PriorityQueue<T> {
    private java.time.LocalDate creationDate;

    public UpgradedPriorityQueue() {
        super();
        creationDate = LocalDate.now();
    }

    public java.time.LocalDate getCreationDate() {
        return this.creationDate;
    }

    public IdObject getElementById(int id) throws WrongClassException {
        if (!(element() instanceof IdObject)) throw new WrongClassException("You do not have the id in the objects in this collection");
        for (T priorityQueueObject: this) {
            IdObject idObject = (IdObject) priorityQueueObject;
            if (idObject.getId() == id) return idObject;
        }
        return null;
    }
}
