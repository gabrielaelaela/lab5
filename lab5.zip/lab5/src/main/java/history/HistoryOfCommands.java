package history;

import commands.HistoryCommand;
import commands.UserCommand;

import java.util.ArrayList;

public class HistoryOfCommands {

    private static HistoryOfCommands instance;
    private ArrayList<UserCommand> listOfCommands = new ArrayList<>();

    private HistoryOfCommands() {}

    public static HistoryOfCommands getInstance() {
        if (instance == null)
            instance = new HistoryOfCommands();
        return instance;
    }

    public void addCommandToHistory(UserCommand command) {
        this.listOfCommands.add(command);
        if (listOfCommands.size() > 10)
            listOfCommands.remove(0);
    }

    public UserCommand get(int index){
        return listOfCommands.get(index);
    }

    public int getLength(){
        return listOfCommands.size();
    }
}
