package constructors;

public interface Constructor {
    public Object askConstruct() throws Exception;
    public Object scanConstruct() throws Exception;
}
