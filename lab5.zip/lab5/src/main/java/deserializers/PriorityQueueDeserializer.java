package deserializers;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.PriorityQueue;

public class PriorityQueueDeserializer {

    private String filename;

    public PriorityQueueDeserializer(String filename) {
        this.filename = filename;
    }

    public UpgradedPriorityQueue deserialize() throws IOException {
        UpgradedPriorityQueue<Organization> upgradedPriorityQueue = new UpgradedPriorityQueue<>();

        Reader reader = Files.newBufferedReader(Paths.get(filename));

        try {
            Gson gson = new Gson();
            Organization[] organizations = gson.fromJson(reader, Organization[].class);
            for (Organization organization: organizations) {
                upgradedPriorityQueue.add(organization);
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            reader.close();
        }

        return upgradedPriorityQueue;
    }
}
