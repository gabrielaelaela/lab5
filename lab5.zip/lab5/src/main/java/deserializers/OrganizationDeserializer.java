package deserializers;

import organization.Organization;

public class OrganizationDeserializer {

    Object organization;

    public OrganizationDeserializer(Object organization) {
        this.organization = organization;
    }

    public Organization toOrganization() {
        return null;
    }

}
