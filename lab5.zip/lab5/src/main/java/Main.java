import commands.UserCommand;
import deserializers.PriorityQueueDeserializer;
import history.HistoryOfCommands;
import iowork.*;
import commands.CommandReader;
import exceptions.WrongInputException;
import organization.Address;
import organization.Coordinates;
import organization.Organization;
import upgradedcollections.UpgradedPriorityQueue;

public class Main {

    public static void main(String[] args) throws Exception {
        Printable printable = new ConsolePrint();

        //UpgradedPriorityQueue<Organization> upgradedPriorityQueue = new UpgradedPriorityQueue<>();

        PriorityQueueDeserializer priorityQueueDeserializer = new PriorityQueueDeserializer("C:\\Users\\ticug\\Desktop\\ITMOStudy\\Programming\\lab5\\test.json");
        UpgradedPriorityQueue<Organization> upgradedPriorityQueue = priorityQueueDeserializer.deserialize();

        CommandReader commandReader = new CommandReader(upgradedPriorityQueue);
        waitForAction(commandReader, printable);
    }

    private static void waitForAction(CommandReader commandReader, Printable printable) throws Exception {
        try {
            UserCommand command = commandReader.commandFromConsole();
            HistoryOfCommands.getInstance().addCommandToHistory(command);
            command.execute();
        } catch (WrongInputException e) {
            printable.print("Wrong input. Please, try again. ");
        } finally {
            waitForAction(commandReader, printable);
        }
    }
}
