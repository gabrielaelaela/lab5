package iowork;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class FilePrint implements Printable{

    BufferedOutputStream bufferedOutputStream;

    public FilePrint(String fileName) throws FileNotFoundException {
        bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(fileName));
    }

    @Override
    public void println(String s) throws IOException {
        bufferedOutputStream.write(s.getBytes(StandardCharsets.UTF_8));
        bufferedOutputStream.close();
    }

    @Override
    public void print(String s) {

    }
}
